from typing import Optional, Iterable, Tuple
from django.db.models import Q, Prefetch
from django.core.paginator import Paginator
from .models import Producto, DetallesProducto, Autor, Categoria, ImagenProducto
