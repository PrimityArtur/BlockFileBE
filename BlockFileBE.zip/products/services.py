from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from decimal import Decimal, InvalidOperation

from django.db import transaction

from . import repository as repo
from .models import Producto, Autor, Categoria
